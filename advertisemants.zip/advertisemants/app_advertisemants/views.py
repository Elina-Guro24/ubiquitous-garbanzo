from django.shortcuts import render
from django.http import HttpResponse
from .models import Advertisemant
from .forms import AdvertisemantForms


# Create your views here.
def index(request):
    advertisemants = Advertisemant.objects.all()
    context = {'advertisemants': advertisemants}
    return render(request, 'index.html', context)

def top_sellers(request):
    return render(request, 'top-sellers.html')

def advertisement_post(request):
    if request.method == 'POST':
        form = AdvertisemantForms(request.POST, request.FILES)
        if form.is_valid():
            advertisement = Advertisemant(**form.cleaned_data)
            advertisement.user = request.user
            advertisement.save()
            url = reverse('main-page')
            return redirect(url)
    
    else:
        form = AdvertisemantForms()
    context = {'form': form}
    return render (request, 'advertisement-post.html', context)

    