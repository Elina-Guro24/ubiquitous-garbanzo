from django.contrib import admin
from .models import Advertisemant
# Register your models here.

class AdvertisemantAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'discription', 'prise', 'create_at', 'auction', 'image']
    list_filter = ['auction', 'create_at']
    actions = ['make_auction_as_false', 'make_auction_as_true']

    @admin.action(description = 'Убрать возможность торга')
    def make_auction_as_false(self, request, qertyset):
        qertyset.update(action = False)
    

    @admin.action(description = 'Добавить возможность торга')
    def make_auction_as_true(self, request, qertyset):
        qertyset.update(action = True)


admin.site.register(Advertisemant, AdvertisemantAdmin)